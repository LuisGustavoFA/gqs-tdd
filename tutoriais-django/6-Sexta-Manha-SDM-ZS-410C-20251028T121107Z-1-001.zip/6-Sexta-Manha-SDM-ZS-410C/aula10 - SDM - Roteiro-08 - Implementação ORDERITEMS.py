####################################
########## Projeto GIT    ########## 
####################################

# Caso esteja iniciando o projeto faça um clone completo de Clone.
# Caso ja tenha começado de um pull no projeto. 


####################################
########## APP orderitems ############ 
####################################

# Adicione as pastas no gitignore e "commit" e "push"

/apps/orderitems/__pycache__/*
/apps/orderitems/migrations/*

# Acesse a pastas "apps" e crie a estrutura basica de um projeto que 
# sera o nucleo desse projeto "orderitems". Como sera necessario acessar 
# a pasta "apps" o caminho da pasta manage.py pode alterar 
# dependendo do seu ambiente. 

# No linuxOS e no MacOS o caminho das barras ao 
# contrario ""../manage.py startapp orderitems" isso 
# tambem serve para as referencias de pastas.
# Acesse a pasta "apps" digitando o comando:

cd apps

# Execute o comando

python ..\manage.py startapp orderitems

# Retorne para a raiz do projeto caso ainda esteja dentro da pasta apps.

cd ..

########
# APPS #
########

# Acesse o arquivo "apps.py" no caminho "apps/orderitems/apps.py".
# Procure na classe "OrderitemsConfig" o atributo "name = 'orderitems" e depois 
# desse atributo adicione a linha com o atributo com a identificao ou nome que 
# voce deseja colocar em seu aplicativo.
   
verbose_name = 'Itens de Pedidos'


############
# SETTINGS #
############

# Acesse o arquivo "settings.py" e procure por INSTALLED_APPS e adicione 
# dentro dos colchetes a nova linha a seguir para declarar os itens de pedidos 
# do projeto "orderitems". Nao esqueca da virgula no final.

'orderitems.apps.OrderitemsConfig',



##########
# MODELS #
##########

# Acesse o arquivo "models.py" no caminho "apps/orderitems/models.py" e 
# construa seus modelos baseado no seu projeto.

# Importe o modelo de "Product" e Order" para adicionar o 
# relacionamento da chave estrangeira 
# indicando a propriedade do modelo ao produtos e clientes criados.

from products.models import Product
from orders.models import Order

# Após o comentario "# Create your models here." e crie a classe "Orderitem" do modelo.

class Orderitem(models.Model):
    quantity = models.PositiveIntegerField('Quantidade',null=True, blank=True,default=0)
    unitary_price = models.DecimalField('Preco unitario', max_digits=10, decimal_places=2)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    
    class Meta:
        unique_together = ('order', 'product')
        verbose_name = 'Item de pedido'
        verbose_name_plural = 'Itens de pedido'
        ordering =['id']

    def __str__(self):
        return f"{self.quantity} - {self.product.name}"


####################################################
#                 serializers                      #
# Conversao dos dados de banco de dados em formato #
# json para que os agentes externos entendam o     #
# formado de dados. O serializer que permite que   #
# dados sejam convertidos para a forma Python      #
# nativa, de modo que o RM do Python entenda, e    #
# que sejam facilmente renderizados em JSON, XML,  #
# ou outros tipos.                                 #
####################################################

# Cria o arquivo "serializer.py" do Django Rest Framework 
# dentro do app "orders"

from .models import Orderitem
from rest_framework import serializers
    
class OrderitemSerializer(serializers.ModelSerializer):
    class Meta:
        model = Orderitem
        fields = '__all__'


#########
# VIEWS #
#########

# Acesse o arquivo "views.py" no caminho "apps/orders/views.py" e 
# construa seus modelos baseado no seu projeto.
# Logo a seguir faça os importes dos seguintes componentes.

from .models import Orderitem
from rest_framework import viewsets
from .serializer import  OrderitemSerializer

# Após o comentario "# Create your views here." e crie as views "Orderitem".
    
class OrderitemViewSet(viewsets.ModelViewSet):
    queryset = Orderitem.objects.all()
    serializer_class = OrderitemSerializer  


########
# URLS #
########

# Criar um "urls.py" dentro dos arquivos de configuracao do pedido em "apps/orderitems".
# Nesse local serao declaradas as urls especificas do App orders. Adicionar ao arquivo 
# as linhas a seguir.

from django.urls import path, include
from . import views
from rest_framework import routers

app_name = 'orderitems'

router = routers.DefaultRouter()
router.register('', views.OrderitemViewSet, basename='itens_pedido')

urlpatterns = [
    path('', include(router.urls) )
]

# Na raiz do projeto acesse o arquivo "urls.py" 
# Adicione o caminho da entidade após "path('admin/', admin.site.urls),".

path('itens_pedido/', include('orderitems.urls', namespace='orderitems')),

# Altere a linha de import "from django.urls import path" adicionando o include

from django.urls import path, include


# Criar uma migracao do projeto a partir do modelo criado pedidos.

python manage.py makemigrations

# Executar efetivamente as migracoes criadas.

python manage.py migrate

# Inicie o servico http e teste a aplicacao no navegador.

python manage.py runserver


