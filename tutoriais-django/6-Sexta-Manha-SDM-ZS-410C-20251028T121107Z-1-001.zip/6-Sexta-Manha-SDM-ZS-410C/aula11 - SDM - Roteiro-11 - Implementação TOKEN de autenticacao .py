####################################################
#        Implementacao do TOKEN autenticacao        #
####################################################

# Edite o arquivo "settings" e adicione no final do INSTALLED_APPS
# o app 'rest_framework.authtoken' nao esqueça de colocar a vircula.

'rest_framework.authtoken'


# Sera necessario fazer migrate para que seja gerado na base de dados a
# tabela de armazenadmento do TOKEN.

python manage.py migrate


# Edite o arquivo "urls" da raiz do projeto
# importe o obtain_auth_token.

from rest_framework.authtoken.views import obtain_auth_token


# Adicionar o Path depois do ultimo registro.
# Defina o URL do token.

 path('token-autenticacao/', obtain_auth_token)


# Acesse a de "View" app que deseja restringir o acesso 
# no nosso caso de "categories" no views.


# import o "TokenAuthentication"

from rest_framework.authentication import TokenAuthentication

# Inseirir no final no viewset o parametro no final.

authentication_classes = [TokenAuthentication]


# import o "IsAuthenticated"

from rest_framework.permissions import IsAuthenticated

# Inseirir no final no viewset o parametro no final.

permission_classes = [IsAuthenticated]



# Criar um TOKEN para o usuario desejado.

python manage.py drf_create_token admin


# ALTERNATIVA 01 para testar "REST CLIENT":

# Baixe a extensao odo vscode "REST Client"

# Crie um arquivo .http ou .rest e insira os seguinte informacao


GET http://localhost:8000/categorias
Authorization: Token SEU_TOKEN

# No conteudo do arquivo aparece o link "Send Request".


# ALTERNATIVA 02 para testar "CONSOLE NAVEGADOR":

# Ou

fetch("http://localhost:8000/categorias", {
  method: "GET",
  headers: {
    "Authorization": "Token SEU_TOKEN"
  }
})
.then(response => response.json())
.then(data => console.log(data))
.catch(error => console.error("Erro:", error));






