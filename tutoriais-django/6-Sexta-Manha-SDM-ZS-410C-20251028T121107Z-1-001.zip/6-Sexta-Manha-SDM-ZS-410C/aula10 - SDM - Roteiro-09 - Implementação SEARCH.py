####################################################
#          Implementacao do SEARCH                 #
# Implenetar pesquisa utilizando o Filter ou o que #
# permite que você crie facilmente filtros         #     
# em relacionamentos ou crie vários tipos de       #
# pesquisa de filtro para um determinado campo.    #
####################################################

# Instalamos na craicao do ambiente 
# o "pip install django-filter"  e podemos 
# habilitalos no INSTALLED_APPS.

# Acesse o arquivo "settings.py" e procure por INSTALLED_APPS e adicione 
# dentro dos colchetes a nova linha a seguir para declarar o django filter.

'django_filters',

#########
# VIEWS #
#########

# Acesse o arquivo "views.py" no caminho "apps/products/views.py" e 
# construa seus modelos baseado no seu projeto. No nosso 
# caso vamos utilizado o Views do Products.
# Logo a seguir faça os importes dos seguintes componentes.

from django_filters.rest_framework import DjangoFilterBackend

# Adicione as variaveis a classe.

filter_backends = [DjangoFilterBackend]
filterset_fields = ['name', 'description', 'category'] # Neste campo coloque somente.

# A classe deve ficar da seguinte forma.

class ProductsViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer 
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['name', 'description', 'category']

# Inicie o servico http e teste a aplicacao no navegador e Teste.

python manage.py runserver

# Para testar deverá aparecer ao lado esquerdo do botao "OPTIONS" um botao "Fitros".

####################################################
#          Otimizacoes de Implementacao            #   
####################################################

# Carregando tudo.

queryset = Product.objects.all()

# Carregando o por filtro.

queryset = Product.objects.filter()

# Carregando o por filtro ordenando por cadecoria decrescente.

queryset = Product.objects.filter().order_by('-category')

# O QuerySet é uma coleção de objetos de um modelo que está pronta 
# para ser utilizada em uma consulta ao banco de dados. 
# Permite que filtre, ordene e realize operações em seus dados 
# antes de obter os resultados efetivos da consulta. 
# Um QuerySet Permite (filtrar, ordenar, etc.) antes de executar a consulta real.
# Ele é uma estrutura de dados Python que o Django usa internamente para construir a consulta SQL apropriada.

# Ela é "Lazy load" não executa a consulta ao banco de dados imediatamente. 
# Ele só é avaliado quando você tenta obter os resultados
# atraves de all(), filter(), first(), exclude(), order_by(), values(), etc.. 
# Cada QuerySet tem um cache para otimizar a performance, ou seja quando um QuerySet é avaliado pela primeira vez, 
# o resultado da consulta é armazenado no cache e em consultas subsequentes, os dados são recuperados do cache,
# evitando consultas redundantes ao banco de dados. 

# O Benefícios para "Acesso a dados grandes" pois evita carregar uma grande quantidade de dados de uma vez,
# o que pode ser mais lento e consumir mais recursos e "Acesso não imediato" o que permite que os dados 
# sejam carregados apenas quando são necessários, melhorando o desempenho geral da aplicação. 

# Existe a outra tecnica "Eager load" carregamento antecipado ou carregamento rápido,
# que carrega todos os dados de uma entidade e seus relacionamentos de forma imediata,
# ao invés de aguardar que sejam solicitados individualmente. Isso significa que, ao carregar um objeto, 
# todos os dados relacionados a ele, como coleções e outras entidades, também são carregados no mesmo momento. 
# Esta tecnica pode levar a problemas de desempenho com grandes conjuntos de dados.

# O "lazy load" pode ser mais adequado para situações onde o acesso aos dados é feito sob demanda, 
# e o "Eager load" pode ser mais adequado quando todos os dados são necessários desde o início. 
   
# A conclusao que "lazy load" é uma técnica que otimiza o carregamento  
# carregando-os sob demanda, o que pode melhorar o desempenho, 
# especialmente com grandes conjuntos de dados ou 
# quando o acesso é feito de forma incremental. 





