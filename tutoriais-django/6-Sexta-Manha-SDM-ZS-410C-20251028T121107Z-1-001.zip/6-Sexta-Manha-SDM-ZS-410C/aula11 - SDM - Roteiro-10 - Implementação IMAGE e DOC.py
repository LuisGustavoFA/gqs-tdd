####################################################
#        Implementacao do IMAGE em Product         #
####################################################

# Instalamos na craicao do ambiente 
# o "conda install Pillow".

conda install Pillow

#########
# Models #
#########

# Acesse o arquivo "models.py" no caminho "apps/products/models.py" e 
# construa seus modelos baseado no seu projeto. No nosso 
# caso vamos utilizado o models do Products.
# Logo a seguir faça os importes dos seguintes componentes.
# Inserir antes do atributo category.

photo = models.ImageField('Foto', upload_to='photos')
doc = models.FileField('Documentos', upload_to='docs')

# Logo a seguir adicione as linha para referenciar a pasta 
# onde serao armazenados arquivos que serao enviados atraves 
# do upload do sistema. Insira no final do arquivo 'settings.py'.

MEDIA_URL = '/media/' 
MEDIA_ROOT = os.path.join(BASE_DIR, 'media') 

# Na raiz do projeto crie a pasta "media".

# Importe as classes do "static" e "settings" para direcionar as urls para o caminhos dos 
# arquivos de uplods.

from django.conf.urls.static import static
from django.conf import settings

# Fora dos conchetes do urlpatterns, depois de todo o codigo insisra a seguinte linha
# para declarar a pasta caminho e raiz para arquivos que sera enviados atraves de 
# forms de upload.

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# Faça a migracao do Products.

python manage.py makemigrations

python manage.py migrate

# Inicie o servico http e teste a aplicacao no navegador e Teste.

python manage.py runserver

