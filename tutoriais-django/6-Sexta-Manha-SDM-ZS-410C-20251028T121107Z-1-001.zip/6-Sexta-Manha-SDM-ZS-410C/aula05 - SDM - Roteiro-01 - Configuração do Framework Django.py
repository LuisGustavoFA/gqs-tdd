####################################################
#                 SOFTWARES                        #
# Instalacao de softwares para desenvolvimento de  #
# software utilizando Framework Django             #
####################################################

# Baixar e instalar Python3.* e nao esquecer de marcar 
# para a adicionar ao Path ou as variaveis de ambiente
# do Sistema Operacional.

https://www.python.org/

# Baixar e instalar o VSCode.

https://code.visualstudio.com/

# Instalar através do VSCode as Extensoes a seguir.

"GitHub Pull Requests and Issues"
"Python for VSCode"

# Baixar e instalar o Git  e nao 
# esquecer de marcar para a "Adicionar ao Path" ou as
# variaveis de ambiente do Sistema Operacional.

https://git-scm.com/

# Baixar e instalar Miniconda para Python3.*. e nao 
# esquecer de marcar para a adicionar ao Path ou as
# variaveis de ambiente do Sistema Operacional.

https://docs.conda.io/ 



############################################
#                  MINICONDA               #
# Criacao de Ambiente virtual isolado para #
# instalacao das bibliotecas necessarias   #
# para o desenvolvimento do projeto        #
############################################

# Crie uma diretorio de nome "projetos".
# Abra o vscode esse diretorio.
# Abra dentro do VSCode o "Command Prompt" do windows
# Na aba do VSCode: view -> Command Pallete 
# procure por "Python: Select Interpreter"
# e selecione a versao do python instalado.

# Criar ambiente virtual de desenvolvimento (Defina
# um nome seguido pela palavra app, por exmeplo "lojaapp"
# ou "projetoapp").

conda create -n nome_do_projeto_que_voce_escolher

# Liste os ambientes criados.

conda env list

# Remover ambiente virtual de desenvolvimento.

conda env remove -n nome_do_projeto_que_voce_escolher 

# Ative o ambiente criado. 
# Verifique se no início da linha comandos aparece o nome 
# do projeto entre parenteses conforme o seguinte exemplo
# "(modeloapp) Antonio:~ antonio$".

conda activate nome_do_projeto_que_voce_escolher

# Desative o ambiente. 
# Verifique se no início da linha de comandos desaparece
# o nome entre parenteses conforme o seguinte exemplo 
# "Antonio:~ antonio$".

conda deactivate


#######################################################
# As etapas a seguir devem ser executadas dentro      #
# do ambiente virtual de desenvolvimento do miniconda #
# para cada projeto. Ou seja com o conda atividado    #
# como por exemplo "(modeloapp) Antonio:~ antonio$"	  #
#######################################################

#############################################
# Instalação de bibliotecas Python e Djando #
#############################################

# Utilizar o terminal(Command Prompt) do VSCODE faça todas as 
# operacoes (Para os usuarios de windows nao utilize o PowerShell)

# Instalar o PIP atraves do Miniconda para gerenciamento de pacotes padrao  
# e usado para instalar e gerenciar pacotes de software escritos em Python 
# (A regra para instalação de pacotes, bibliotecas  e dependências, será 
# sempre instalar com o MINICONDA e caso nao tenha utilizar o PIP).

conda install pip

# Instalar Biblioteca "python-decouple" para esconder informações 
# importantes por segurança como as de banco de dados e chave de
# registro do sistema em um arquivo separado chamado exatamente de
# ".env" com essas informações.

pip install python-decouple

# Instalar o Framework Django.

pip install "django==4.2.11"

# Instalar Biblioteca do driver do banco de dados oracle 
# "oracledb" para rodar no Framework Django.

pip install "oracledb==1.4.0"

# Instalar biblioteca "Pillow" para tratar e resolver imagens
# para campos do Model Fields (ImageFields).

conda install Pillow

####################################################
# Instalacao de softwares para desenvolvimento de  #
# software relacionados ao Django Rest Framework . #
####################################################

# Instalcao do Django Rest Framework.

pip install "djangorestframework==3.14.0"

# Instalacao Markdown, 
# suporte para o navegador rodar as API
# trata-se de um conversor. Markdown refere-se à linguagem de 
# formatação de texto simples, enquanto "Django REST Framework" 
# é um poderoso framework para construir APIs RESTful. Usar 
# Markdown dentro de uma aplicação Django REST, especialmente 
# quando combinado com renderizadores, permite a apresentação 
# de conteúdo em diferentes formatos, como Markdown, 
# que pode ser convertido para HTML. 

pip install markdown   

# Instalacao diango-filter 
# permite que você crie facilmente filtros em relacionamentos 
# ou crie vários tipos de pesquisa de filtro para 
# um determinado campo.

pip install django-filter


############################################
# Conferência de instalação de Bibliotecas #
############################################

# Digite o comando para listas as bibliotecas instaladas.

pip list

# Digite o comando para listas as bibliotecas instaladas.

conda list


##############################################
# Criacao e configuracao do Framework Django #
##############################################

# Crie um projeto Django em um diretório de sua escolha onde
# ficarao todos os seus projetos (Defina com o mesmo nome do 
# ambiente virtual por exmeplo "lojaapp" ou "projetoapp").

django-admin startproject nome_do_projeto_que_voce_escolher

# O comando criará a seguinte estrutura de pastas.

  (RAIZ)nome_do_projeto_que_voce_escolher
      .   
      ├── manage.py
      └── nome_do_projeto_que_voce_escolher
          ├── __init__.py
          ├── asgi.py
          ├── settings.py
          ├── urls.py
          └── wsgi.py
          

# Acesse o "settings.py" e comente as linhas de configuracao
# do banco de dados SQLite. Procure por "DATABASES" e comente
# as linhas a seguir.

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}


# Acesse o diretorio RAIZ do projeto criado, e através do 
# terminal inicie o serviço do Django. Lembre que dependendo
# do sitema operacional o "manage.py" pode ser executado de
# forma diferente, por exemplo sem o ".\" .

python manage.py runserver

# Depedendo da forma que o python foi instalado ele precisa 
# ser executado com a chamada do Python na frente.

python manage.py runserver

# Acessar um navegador de sua escolha, digitar para testar o 
# servico de servidor web socket criado pelo django.

http://localhost:8000

# Para parar o serviço.

Ctrl + C 

# Caso desejar iniciar o serviço utilizando outra porta
#  como por exemplo 8001.

python manage.py runserver 8001


# Crie um arquivo na Raiz do projeto como nome de ".gitignore"
# declare o caminho dos diretorios que deseja ignorar
# o * significa que vai ignorar todos os arquivos dentro 
# do diretorio em questao conforme apresentado a seguir

modeloapp/__pycache__/*
/apps/categories/__pycache__/*
/apps/categories/migrations/*

