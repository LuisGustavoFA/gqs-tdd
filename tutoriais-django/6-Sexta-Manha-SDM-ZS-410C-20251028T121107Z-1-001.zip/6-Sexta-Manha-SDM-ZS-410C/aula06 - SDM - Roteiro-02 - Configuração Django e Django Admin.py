######################################################
# Configurações gerais do Django e do banco de dados #
######################################################

# No VSCode abra o arquivo de configurações do Django "settings.py".

# No "settings.py" no inicio do arquivo importar a modulo "OS" antes 
# do "from pathlib import Path". Serve para manipular funcionalidades
# do sistema operacional.

import os

# No "settings.py" no inicio do arquivo importar modulo "SYS" apos 
# "import os". Fornece funcoes e variaveis ​​usadas para manipular 
# partes do ambiente de tempo de execucao do Python.

import sys 

# No "settings.py" procure pela linha "from pathlib import Path" e 
# apos digite a linha a seguir para importar a biblioteca "decouple" 
# que server para esconder os dados de conexao do postgres garantindo 
# a seguranca.

from decouple import config

# No "settings.py" procure pela linha "BASE_DIR". Essa alteracao 
# muda o caminho do path dos diretorios de acesso do django.

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# No "settings.py" procure pela linha "SECRET_KEY" copie a chave de 
# seguranca que esta entre aspas e salve em um lugar seguro (Nao perca 
# a chave em hipotese alguma). Apos guardar a chave aleatorio substitua
# a linha pela seguinte descricao. Esse processo garantiara a seguranca
# do projeto.

SECRET_KEY = config('SECRET_KEY')

# No "settings.py" procure pela linha "DEBUG" e substitua a linha pela
# seguinte descricao. Esse procedimento tambem sera passado para um
# arquivo que ficara oculto.

DEBUG = config('DEBUG', default=False, cast=bool)

# "No "settings.py" procure pela linha DATABASES onde encontrara as 
# configurações do sqlite3, banco de dados local nativo do Djando. 
# Todo o conteudo devera ser substituido pelas seguintes informacoes
# de forma que os dados de acesso serao colocados em um arquivo de 
# CONFIG oculto assim como os dados do SECRET_KEY e DEBUG.

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.oracle',
         'NAME': config('DB_NAME'),
         'USER': config('DB_USER'),
         'PASSWORD': config('DB_PASSWORD'),   
    }
}

# Esses procedimentos permitiram esconder as informacoes 
# importantes de seguranca. Agora para finalizar vamos criar
# esse arquivo de configuracao.
# Criar um arquivo no o nome especifico de ".env" na raiz do 
# projeto "(RAIZ)nome_do_projeto_que_voce_escolher" e inserir 
# as informacoes a seguir e salvar.
SECRET_KEY=Insira aqui a chave gerada sem aspas
DEBUG=True
DB_NAME=Caminho do seu banco oracle: "Connection string" do TNS em Database connection (ORACLE OCI) 
DB_USER=admin
DB_PASSWORD=Ritter*123456

# Altere no arquivo "settings.py" o idioma 
# e o horário que usaremos na aplicação, 
# procure e altere as seguintes linhas de 
# código "LANGUAGE_CODE" e "TIME_ZONE":

LANGUAGE_CODE = 'pt-br'

TIME_ZONE = 'America/Sao_Paulo'


# Teste o ambiente Django

python manage.py runserver

# Acesse um navegador de Internet e digite o endereco:

http://127.0.0.1:8000/ 

# ou 

http://localhost:8000/


#############################################################
##### Migracoes e Geracao de entidades no banco de dados ####
#############################################################

# Django Framework trabalha com Mapeamento Objeto-Relacional(ORM) 
# para percistencia de dados e migra as aplicacões existentes do 
# Django atraves das classes dos objetos criados gerando o banco 
# de dados baseado nessa estrutura.

# Comando de migracao necessario apos alteracoes nos objetos sao:
# "makemigrations" e "migrate".

python manage.py migrate

# Criar um usuario dentro da aplicacao do admin do Django.

python manage.py createsuperuser

# Defina o nome de usuario "admin", um email e senha valida
# sugestao "123456" e confirmar.
# Acesse um navegador de Internet e digite o endereco.
# Acessar o admin com os usuario e senha criados.

http://127.0.0.1:8000/ 

# ou 

http://localhost:8000/

